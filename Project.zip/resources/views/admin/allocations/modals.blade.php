<!-- Modal آپلود Excel -->
<div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" dir="rtl">
            <div class="modal-header text-end">
                <h5 class="modal-title" id="importModalLabel">آپلود فایل Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body text-end">
                <form action="{{ route('allocations.import') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3 text-end">
                        <label for="excelFile" class="form-label">فایل Excel</label>
                        <input type="file" name="file" class="form-control" id="excelFile" required>
                    </div>

                    <div class="d-flex justify-content-between">
                        <button type="submit" class="btn btn-primary">آپلود</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">لغو</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true" dir="rtl">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header text-end">
                <h5 class="modal-title">ویرایش تخصیص</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="editForm">
                    @csrf
                    @method('PUT')

                    <input type="hidden" name="id" id="edit_id">

                    <div class="row g-2">
                        <div class="col-md-3">
                            <label class="form-label">ردیف</label>
                            <input type="text" name="row" id="edit_row" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">شهرستان</label>
                            <input type="text" name="Shahrestan" id="edit_Shahrestan" class="form-control text-end">
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">سال</label>
                            <input type="number" name="sal" id="edit_sal" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">تاریخ ارجاع</label>
                            <input type="text" id="edit_erja_picker" class="form-control text-end">
                            <input type="hidden" name="erja" id="edit_erja">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">کلاسه پرونده</label>
                            <input type="text" name="kelace" id="edit_kelace" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">متقاضی</label>
                            <input type="text" name="motaghasi" id="edit_motaghasi" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">مصرف</label>
                            <input type="text" name="masraf" id="edit_masraf" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">مصوب دبی (q_m)</label>
                            <input type="number" name="q_m" id="edit_q_m" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">حجم (V_m)</label>
                            <input type="number" name="V_m" id="edit_V_m" class="form-control text-end">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">جمع</label>
                            <input type="number" step="0.001" name="sum" id="edit_sum"
                                class="form-control text-end">
                        </div>

                        {{-- <div class="col-md-3">
                            <label class="form-label">باقی‌مانده</label> --}}
                        <input type="hidden" step="0.001" name="baghi" id="edit_baghi"
                            class="form-control text-end">
                        {{-- </div> --}}

                        <div class="col-12">
                            <label class="form-label">مصوبات</label>
                            <input type="text" name="mosavabat" id="edit_mosavabat"
                                class="form-control text-end">
                        </div>
                    </div>

                </form>
            </div>

            <div class="modal-footer">
                <button type="button" id="saveEditBtn" class="btn btn-primary">ذخیره تغییرات</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
            </div>
        </div>
    </div>
</div>
