@component('admin.layouts.content')

    @section('content')
        <div class="container" dir="rtl">
            <h1 class="mb-4 text-end">ایجاد رکورد جدید تخصیص</h1>

            {{-- نمایش پیام موفقیت --}}
            @if (session('success'))
                <div class="alert alert-success text-end">{{ session('success') }}</div>
            @endif

            {{-- نمایش ارورهای اعتبارسنجی --}}
            @if ($errors->any())
                <div class="alert alert-danger text-end">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li class="text-end">{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- فرم ایجاد رکورد --}}
            <form action="{{ route('allocations.store') }}" method="POST">
                @csrf
                <div class="row g-3 d-flex">

                    {{-- ردیف --}}
                    <div class="col-md-2">
                        <label class="form-label">ردیف</label>
                        <input type="text" name="row" class="form-control text-end" value="{{ old('row', $nextRow) }}"
                            required>
                    </div>

                    {{-- شهرستان --}}
                    <div class="col-md-2">
                        <label class="form-label">شهرستان</label>
                        <select name="Shahrestan" class="form-control text-end">
                            <option value="">انتخاب کنید</option>
                            @foreach ($shahrOptions as $option)
                                <option value="{{ $option }}" {{ old('Shahrestan') == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- سال --}}
                    <div class="col-md-2">
                        <label class="form-label">سال</label>
                        <input type="number" name="sal" class="form-control text-end" value="{{ old('sal') }}">
                    </div>

                    {{-- تاریخ ارجاع --}}
                    <div class="col-md-2">
                        <label class="form-label">تاریخ ارجاع</label>
                        <input type="text" id="erja_picker" class="form-control text-end" value="{{ old('erja') }}"
                            placeholder="۱۴۰۳/۰۱/۰۱">
                        <input type="hidden" name="erja" id="erja" value="{{ old('erja') }}">
                    </div>

                    {{-- کد محدوده --}}
                    <div class="col-md-2">
                        <label class="form-label">کد محدوده</label>
                        <input type="number" name="code" class="form-control text-end" id="field_code"
                            value="{{ old('code') }}">
                    </div>

                    {{-- نوع منطقه --}}
                    <div class="col-md-2">
                        <label class="form-label">نوع منطقه</label>
                        <select name="mantaghe" class="form-control text-end">
                            <option value="">انتخاب کنید</option>
                            @foreach ($mantagheOptions as $option)
                                <option value="{{ $option }}" {{ old('mantaghe') == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- نام آبادی --}}
                    <div class="col-md-2">
                        <label class="form-label">نام آبادی</label>
                        <input type="text" name="Abadi" class="form-control text-end" value="{{ old('Abadi') }}">
                    </div>

                    {{-- کلاسه پرونده --}}
                    <div class="col-md-2">
                        <label class="form-label">کلاسه پرونده</label>
                        <input type="text" name="kelace" class="form-control text-end" value="{{ old('kelace') }}"
                            required>
                    </div>

                    {{-- نام متقاضی --}}
                    <div class="col-md-2">
                        <label class="form-label">نام متقاضی</label>
                        <input type="text" name="motaghasi" class="form-control text-end" value="{{ old('motaghasi') }}">
                    </div>

                    {{-- نوع درخواست --}}
                    <div class="col-md-2">
                        <label class="form-label">نوع درخواست</label>
                        <select name="darkhast" class="form-control text-end">
                            <option value="">انتخاب کنید</option>
                            @foreach ($darkhastOptions as $option)
                                <option value="{{ $option }}" {{ old('darkhast') == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- تخصیص -->
                    <div class="col-md-2">
                        <label class="form-label">تخصیص</label>
                        <select name="Takhsis_group" class="form-control text-end" id="field_Takhsis_group">
                            <option value="">انتخاب کنید</option>
                            @foreach ($takhsisOptions as $option)
                                <option value="{{ $option }}" {{ old('Takhsis_group') == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- مصرف --}}
                    <div class="col-md-2">
                        <label class="form-label">مصرف</label>
                        <input type="text" name="masraf" class="form-control text-end" value="{{ old('masraf') }}">
                    </div>

                    {{-- تاریخ تشکیل کمیته --}}
                    <div class="col-md-2">
                        <label class="form-label">تاریخ تشکیل کمیته</label>
                        <input type="text" id="comete_picker" class="form-control text-end" value="{{ old('comete') }}"
                            placeholder="۱۴۰۳/۰۱/۰۱">
                        <input type="hidden" name="comete" id="comete" value="{{ old('comete') }}">
                    </div>

                    {{-- شماره مصوبه --}}
                    <div class="col-md-2">
                        <label class="form-label">شماره مصوبه</label>
                        <input type="text" name="shomare" class="form-control text-end" value="{{ old('shomare') }}">
                    </div>

                    {{-- تاریخ مصوبه --}}
                    <div class="col-md-2">
                        <label class="form-label">تاریخ مصوبه</label>
                        <input type="text" id="date_shimare_picker" class="form-control text-end"
                            value="{{ old('date_shimare') }}" placeholder="۱۴۰۳/۰۱/۰۱">
                        <input type="hidden" name="date_shimare" id="date_shimare" value="{{ old('date_shimare') }}">
                    </div>

                    {{-- واحد دبی --}}
                    <div class="col-md-2">
                        <label class="form-label">واحد دبی</label>
                        <select name="vahed" class="form-control text-end">
                            <option value="">انتخاب کنید</option>
                            @foreach ($vahedOptions as $option)
                                <option value="{{ $option }}" {{ old('vahed') == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    {{-- مصوب دبی --}}
                    <div class="col-md-2">
                        <label class="form-label">مصوب دبی</label>
                        <input type="number" name="q_m" class="form-control text-end" value="{{ old('q_m') }}">
                    </div>

                    {{-- حجم دبی --}}
                    <div class="col-md-2">
                        <label class="form-label">حجم دبی</label>
                        <input type="number" step="0.001" name="V_m" class="form-control text-end" id="field_V_m"
                            value="{{ old('V_m') }}">
                    </div>

                    {{-- تخصیص پنجم --}}
                    <div class="col-md-2">
                        <label class="form-label">تخصیص پنجم</label>
                        <input type="number" step="0.001" name="t_mosavvab" id="field_t_mosavvab"
                            class="form-control text-end" value="{{ old('t_mosavvab') }}">
                    </div>

                    {{-- sum (readonly) --}}
                    <div class="col-md-2">
                        <label class="form-label">جمع (sum)</label>
                        <input type="number" step="0.001" name="sum" id="field_sum" class="form-control text-end"
                            readonly value="{{ old('sum') }}">
                    </div>

                    {{-- باقی مانده --}}
                    <div class="col-md-2">
                        <label class="form-label">باقی مانده</label>
                        <input type="number" step="0.001" name="baghi" id="field_baghi" class="form-control text-end"
                            value="{{ old('baghi') }}">
                    </div>

                    {{-- مصوبات --}}
                    <div class="col-md-2">
                        <label class="form-label">مصوبات</label>
                        <input type="text" name="mosavabat" class="form-control text-end"
                            value="{{ old('mosavabat') }}">
                    </div>

                </div>

                <div class="mt-3 text-end">
                    <button type="submit" class="btn btn-success">ذخیره رکورد</button>
                    <a href="{{ route('allocations.index') }}" class="btn btn-secondary">بازگشت</a>
                </div>
            </form>
        </div>

        {{-- === CDN های مورد نیاز برای datepicker شمسی === --}}
        <link rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/css/persian-datepicker.min.css">
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/persian-date@1.1.0/dist/persian-date.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/persian-datepicker@1.2.0/dist/js/persian-datepicker.min.js"></script>

        <script>
            $(function() {

                // تبدیل اعداد فارسی به انگلیسی
                function convertPersianNumbersToEnglish(str) {
                    if (!str) return str;
                    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
                    let result = str;
                    persianNumbers.forEach((num, index) => {
                        result = result.replace(new RegExp(num, 'g'), index);
                    });
                    return result;
                }

                // راه‌اندازی datepicker برای هر فیلد
                function initDatepicker(pickerId, hiddenId) {
                    $("#" + pickerId).persianDatepicker({
                        format: 'YYYY/MM/DD',
                        observer: true,
                        autoClose: true,
                        initialValue: false,
                        toolbox: {
                            calendarSwitch: {
                                enabled: false
                            }
                        },
                        onSelect: function() {
                            var val = convertPersianNumbersToEnglish($('#' + pickerId).val());
                            $('#' + hiddenId).val(val);
                        }
                    });

                    // مقدار اولیه hidden
                    var val = convertPersianNumbersToEnglish($('#' + pickerId).val());
                    if (val) $('#' + hiddenId).val(val);
                }

                initDatepicker('erja_picker', 'erja');
                initDatepicker('comete_picker', 'comete');
                initDatepicker('date_shimare_picker', 'date_shimare');

                // قبل از submit مطمئن شو hidden ها درست هستند
                $('form').on('submit', function() {
                    $('#erja').val(convertPersianNumbersToEnglish($('#erja_picker').val()));
                    $('#comete').val(convertPersianNumbersToEnglish($('#comete_picker').val()));
                    $('#date_shimare').val(convertPersianNumbersToEnglish($('#date_shimare_picker').val()));
                });

            });
        </script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // تبدیل ارقام فارسی -> انگلیسی و جداکننده‌های اعشاری فارسی
                function persianToEnglishNumberString(str) {
                    if (str === null || str === undefined) return '';
                    let s = String(str).trim();
                    // ارقام فارسی
                    s = s.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d));
                    // حذف جداکننده هزار
                    s = s.replace(/,/g, '').replace(/٬/g, '');
                    // تبدیل جداکننده اعشاری فارسی به نقطه
                    s = s.replace(/٫/g, '.');
                    return s;
                }

                // خواندن مقدار عددی (float) از input
                function getNumericValueFloat(selector) {
                    const el = document.querySelector(selector);
                    if (!el) return null;
                    const raw = el.value;
                    if (!raw) return null;
                    const eng = persianToEnglishNumberString(raw);
                    const n = parseFloat(eng);
                    return Number.isFinite(n) ? n : null;
                }

                const tEl = document.querySelector('input[name="t_mosavvab"]');
                const sumEl = document.querySelector('input[name="sum"]');
                const baghiEl = document.querySelector('input[name="baghi"]');

                if (!tEl || !sumEl || !baghiEl) return;

                function recalcBaghi() {
                    const tVal = getNumericValueFloat('input[name="t_mosavvab"]');
                    const sVal = getNumericValueFloat('input[name="sum"]');

                    if (tVal === null || sVal === null) {
                        baghiEl.value = '';
                        return;
                    }

                    const diff = tVal - sVal;
                    // نمایش با 3 رقم اعشار (می‌توانی تغییر دهی)
                    baghiEl.value = (Math.round(diff * 1000) / 1000).toString();

                    // هایلایت کوتاه برای جلب توجه
                    baghiEl.style.transition = 'background-color 0.25s ease';
                    baghiEl.style.backgroundColor = '#fff3cd'; // زرد کم‌رنگ
                    setTimeout(() => baghiEl.style.backgroundColor = '', 400);
                }

                ['input', 'change', 'blur'].forEach(ev => {
                    tEl.addEventListener(ev, recalcBaghi);
                    sumEl.addEventListener(ev, recalcBaghi);
                });

                // محاسبه اولیه اگر مقدار old موجود است
                recalcBaghi();
            });
        </script>

        @push('scripts')
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const meta = document.querySelector('meta[name="csrf-token"]');
                    const csrf = meta ? meta.getAttribute('content') : '{{ csrf_token() }}';

                    const elCode = document.getElementById('field_code');
                    const elTakhsis = document.getElementById('field_Takhsis_group');
                    const elVm = document.getElementById('field_V_m');
                    const elSum = document.getElementById('field_sum');

                    function persianToEnglish(str) {
                        if (str === null || str === undefined) return '';
                        let s = String(str).trim();
                        const pers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
                        pers.forEach((p, i) => s = s.replace(new RegExp(p, 'g'), i));
                        s = s.replace(/٬/g, ',').replace(/,/g, '').replace(/٫/g, '.');
                        s = s.replace(/\s+/g, '');
                        return s;
                    }

                    function debounce(fn, wait = 300) {
                        let t;
                        return function(...args) {
                            clearTimeout(t);
                            t = setTimeout(() => fn.apply(this, args), wait);
                        };
                    }

                    async function computeAndSetSum() {
                        if (!elSum) return;
                        // prepare payload
                        const code = elCode ? (elCode.value ? elCode.value.trim() : '') : '';
                        const takhsis = elTakhsis ? (elTakhsis.value ? elTakhsis.value : '') : '';
                        const vmRaw = elVm ? elVm.value : '';
                        const vm = vmRaw ? parseFloat(persianToEnglish(vmRaw)) : 0;

                        console.log('[computeSum] sending payload', {
                            code,
                            takhsis,
                            vm
                        });

                        try {
                            const res = await fetch("{{ route('allocations.computeSum') }}", {
                                method: 'POST',
                                credentials: 'same-origin',
                                headers: {
                                    'Content-Type': 'application/json',
                                    'X-CSRF-TOKEN': csrf,
                                    'Accept': 'application/json'
                                },
                                body: JSON.stringify({
                                    code: code === '' ? null : code,
                                    Takhsis_group: takhsis === '' ? null : takhsis,
                                    V_m: vm
                                })
                            });

                            console.log('[computeSum] response status', res.status);
                            if (!res.ok) {
                                const txt = await res.text().catch(() => null);
                                console.warn('[computeSum] server error', txt);
                                // fallback: set elSum to current vm only
                                elSum.value = vm ? vm : '';;
                                return;
                            }

                            const json = await res.json();
                            console.log('[computeSum] response json', json);

                            if (json && typeof json.sum !== 'undefined') {
                                // ensure numeric
                                const s = parseFloat(json.sum);
                                elSum.value = isNaN(s) ? (vm ? Number(vm).toFixed(3) : '') : Number(s).toFixed(3);
                            } else {
                                // fallback
                                elSum.value = vm ? Number(vm).toFixed(3) : '';
                            }

                        } catch (err) {
                            console.error('[computeSum] exception', err);
                            elSum.value = vm ? Number(vm).toFixed(3) : '';
                        }
                    }

                    const deb = debounce(computeAndSetSum, 300);

                    if (elCode) elCode.addEventListener('input', deb);
                    if (elTakhsis) elTakhsis.addEventListener('change', deb);
                    if (elVm) elVm.addEventListener('input', deb);

                    // initial
                    deb();
                });
            </script>
        @endpush
    @endsection

@endcomponent
