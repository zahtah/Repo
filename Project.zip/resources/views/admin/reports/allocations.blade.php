@component('admin.layouts.content')
    @section('title', 'گزارش تخصیص‌ها')

@section('content')
    <div class="container-fluid py-3">

        <div class="card mb-3">
            <div class="card-body">
                <form id="filtersForm" method="GET" action="{{ route('reports.allocations') }}"
                    class="row g-2 align-items-center">

                    <div class="col-auto">
                        <label class="form-label small">گروه تخصیص</label>
                        <select name="Takhsis_group" id="filterTakhsis" class="form-select form-select-sm">
                            <option value="all">همه</option>
                            @foreach ($takhsisOptions as $opt)
                                <option value="{{ $opt }}"
                                    {{ isset($takhsis) && $takhsis == $opt ? 'selected' : '' }}>{{ $opt }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-auto">
                        <label class="form-label small">کد محدوده مطالعاتی</label>
                        <select name="code" id="filterCode" class="form-select form-select-sm">
                            <option value="all">همه</option>
                            @foreach ($codesAll as $c)
                                <option value="{{ $c }}" {{ isset($code) && $code == $c ? 'selected' : '' }}>
                                    {{ $c }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-auto align-self-end">
                        <button type="submit" class="btn btn-primary btn-sm">اعمال فیلتر</button>
                        <a href="{{ route('reports.allocations') }}" class="btn btn-outline-secondary btn-sm">ریست</a>
                    </div>
                </form>
            </div>
        </div>

        {{-- جدول گزارش --}}
        <div class="card">
            <div class="card-body p-2">
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered mb-0 allocation-table">
                        <thead class="table-light text-center">
                            <tr>
                                <th>کد محدوده مطالعاتی</th>
                                <th>حجم کل (t_mosavvab)</th>
                                <th>هزینه (sum)</th>
                                <th>مانده (baghi)</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($rows as $r)
                                <tr class="text-center">
                                    <td>{{ $r->code }}</td>
                                    <td>{{ number_format($r->total_volume, 2) }}</td>
                                    <td>{{ number_format($r->cost, 2) }}</td>
                                    <td>{{ number_format($r->remaining, 2) }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center">رکوردی برای نمایش وجود ندارد.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card-footer d-flex justify-content-between align-items-center">
                <div class="text-muted small">
                    نمایش {{ $rows->firstItem() ?? 0 }} تا {{ $rows->lastItem() ?? 0 }} از {{ $rows->total() }} رکورد
                </div>
                <div>
                    {{ $rows->withQueryString()->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const takhsis = document.getElementById('filterTakhsis');
            const code = document.getElementById('filterCode');

            takhsis?.addEventListener('change', async function() {
                const val = takhsis.value;
                try {
                    const res = await fetch("{{ route('reports.allocations.codes') }}?Takhsis_group=" +
                        encodeURIComponent(val), {
                            headers: {
                                'Accept': 'application/json'
                            },
                            credentials: 'same-origin'
                        });
                    if (!res.ok) throw new Error('خطا هنگام خواندن کدها');
                    const json = await res.json();
                    const codes = json.codes || [];
                    // پاکسازی و افزودن گزینه‌ها
                    code.innerHTML = '<option value="all">همه</option>';
                    codes.forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c;
                        opt.textContent = c;
                        code.appendChild(opt);
                    });
                } catch (e) {
                    console.error(e);
                }
            });
        });
    </script>
@endpush
@endcomponent
