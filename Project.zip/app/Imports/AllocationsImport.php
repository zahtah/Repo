<?php

namespace App\Imports;

use App\Models\Allocation;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Carbon\Carbon;
use Morilog\Jalali\Jalalian;
use PhpOffice\PhpSpreadsheet\Shared\Date as ExcelDate;

class AllocationsImport implements ToModel, WithHeadingRow
{
    /**
     * accumulator keeps track of V_m sums we've already inserted
     * for a given (code|Takhsis_group) while processing THIS import.
     * Format: [ "code|group" => float(totalVmSoFarFromThisImport) ]
     */
    protected $accumulator = [];

    public function model(array $row)
    {
        // normalize and fetch values (flexible key matching)
        $code = $this->getValue($row, 'code');
        $takhsis = $this->getValue($row, 'Takhsis_group') ?? $this->getValue($row, 'takhsis_group');
        $vmRaw = $this->getValue($row, 'V_m') ?? $this->getValue($row, 'v_m') ?? $this->getValue($row, 'V_m3') ?? 0;
        $v_m = $this->toFloat($vmRaw);

        // key for accumulator
        $key = ($code === null ? '::NULL::' : (string)$code) . '|' . ($takhsis === null ? '::NULL::' : (string)$takhsis);

        // 1) sum of V_m already in DB (existing rows before this import)
        $query = Allocation::query();
        if ($code !== null && $code !== '') {
            $query->where('code', $code);
        } else {
            $query->whereNull('code');
        }

        if ($takhsis !== null && $takhsis !== '') {
            $query->where('Takhsis_group', $takhsis);
        } else {
            $query->whereNull('Takhsis_group');
        }

        $otherSumInDb = (float) $query->sum('V_m');

        // 2) plus sum of V_m from rows already processed in THIS import (accumulator)
        $otherSumFromImport = $this->accumulator[$key] ?? 0.0;

        // final sum = db + imported-so-far + this row's V_m
        $finalSum = $otherSumInDb + $otherSumFromImport + $v_m;

        // update accumulator: include current row's V_m for following rows
        $this->accumulator[$key] = $otherSumFromImport + $v_m;

        // t_mosavvab
        $t_m = $this->toFloat($this->getValue($row, 't_mosavvab') ?? $this->getValue($row, 't_m'));

        // compute baghi if t_m present
        $baghi = is_null($t_m) ? null : ($t_m - $finalSum);

        // truncate to 2 decimals (no rounding) and format for DB
        $finalSumTrunc = floor($finalSum * 100) / 100;
        $baghiTrunc = is_null($baghi) ? null : (floor($baghi * 100) / 100);

        // parse date fields using convertJalali
        $erja = $this->convertJalali($this->getValue($row, 'erja'));
        $comete = $this->convertJalali($this->getValue($row, 'comete'));
        // the user asked for 'date-shimare' mapping — try different variants
        $dateShimareRaw = $this->getValue($row, 'date-shimare') ?? $this->getValue($row, 'date_shimare') ?? $this->getValue($row, 'date shimare');
        $date_shimare = $this->convertJalali($dateShimareRaw);

        // build allocation attributes (adjust keys according to your headings)
        return new Allocation([
            'row' => $this->getValue($row, 'row'),
            'Shahrestan' => $this->getValue($row, 'Shahrestan'),
            'sal' => $this->toInt($this->getValue($row, 'sal')),
            'erja' => $erja,
            'code' => $code,
            'mantaghe' => $this->getValue($row, 'mantaghe'),
            'Abadi' => $this->getValue($row, 'Abadi'),
            'kelace' => $this->getValue($row, 'kelace'),
            'motaghasi' => $this->getValue($row, 'motaghasi'),
            'darkhast' => $this->getValue($row, 'darkhast'),
            'Takhsis_group' => $takhsis,
            'masraf' => $this->getValue($row, 'masraf'),
            'comete' => $comete,
            'shomare' => $this->getValue($row, 'shomare'),
            'date_shimare' => $date_shimare,
            'vahed' => $this->getValue($row, 'vahed'),
            'q_m' => $this->toFloat($this->getValue($row, 'q_m')),
            'V_m' => $v_m,
            't_mosavvab' => $t_m,
            // store truncated values with two decimals (string format for safety)
            'sum' => number_format($finalSumTrunc, 2, '.', ''),
            'baghi' => is_null($baghiTrunc) ? null : number_format($baghiTrunc, 2, '.', ''),
            'mosavabat' => $this->getValue($row, 'mosavabat'),
        ]);
    }

    /**
     * convertJalali: robust conversion for excel/jalali/text dates -> Y-m-d
     * (uses Carbon, PhpSpreadsheet ExcelDate, and Morilog\Jalali\Jalalian)
     */
    private function convertJalali($value)
    {
        if (!$value && $value !== 0) return null;

        // 1) اگر عددی (تاریخ اکسل)
        if (is_numeric($value)) {
            try {
                return Carbon::instance(ExcelDate::excelToDateTimeObject((float)$value))->format('Y-m-d');
            } catch (\Throwable $e) {
                // ادامه برای حالت‌های متنی
            }
        }

        // 2) نرمال‌سازی اولیه: تبدیل ارقام فارسی و حذف کاراکترهای اضافی
        $trans = [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            "\x{200F}"=>'', "\x{200E}"=>'', "\x{FEFF}"=>'' // حذف BOM و راست‌چین‌های نامرئی
        ];
        $v = trim(strtr((string)$value, $trans));

        // حذف نقاط/کامای اضافی در انتها و کاراکترهای غیرمرتبط
        $v = rtrim($v, ".\t ");

        // استاندارد کردن جداکننده‌ها به "/"
        $v = preg_replace('/[.\-,\x{2212}\s]+/u', '/', $v);

        // حالا جدا کن
        $parts = preg_split('/\//', $v);
        if (count($parts) >= 3) {
            // سال دو رقمی؟ 90 -> 1390
            if (mb_strlen($parts[0]) === 2) {
                $parts[0] = '13' . $parts[0];
            }

            // pad ماه و روز
            $year = $parts[0];
            $month = str_pad(preg_replace('/\D/','', $parts[1]), 2, '0', STR_PAD_LEFT);
            $day = str_pad(preg_replace('/\D/','', $parts[2]), 2, '0', STR_PAD_LEFT);

            $jalali = "{$year}/{$month}/{$day}";
            try {
                return Jalalian::fromFormat('Y/m/d', $jalali)->toCarbon()->format('Y-m-d');
            } catch (\Throwable $e) {
                // اگر تبدیل Jalali شکست خورد، ادامه می‌دهیم به تلاش‌های دیگر
            }
        }

        // تلاش برای parse با Carbon (برای فرمت‌های میلادی یا قابل parse دیگر)
        try {
            return Carbon::parse($v)->format('Y-m-d');
        } catch (\Throwable $e) {
            Log::warning('Date parse failed in AllocationsImport', ['value' => $value]);
            return null;
        }
    }

    /**
     * flexible getter: tries different key variants in the $row (heading row mapping)
     */
    protected function getValue(array $row, $key)
    {
        if (array_key_exists($key, $row)) return $row[$key];

        $lower = mb_strtolower($key);
        if (array_key_exists($lower, $row)) return $row[$lower];

        // try normalized key (remove non-alphanum)
        $normKey = preg_replace('/[^a-z0-9]/i', '', mb_strtolower($key));
        foreach ($row as $k => $v) {
            $nk = preg_replace('/[^a-z0-9]/i', '', mb_strtolower($k));
            if ($nk === $normKey) return $v;
        }

        return null;
    }

    protected function toFloat($v)
    {
        if ($v === null || $v === '') return 0.0;
        if (is_numeric($v)) return (float)$v;
        $s = (string) $v;
        // replace persian digits
        $pers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
        foreach ($pers as $i => $p) $s = str_replace($p, (string)$i, $s);
        // remove thousands separators and spaces, unify decimal separator
        $s = str_replace(['٬', ','], ['', ''], $s);
        $s = str_replace('٫', '.', $s);
        $s = trim($s);
        return is_numeric($s) ? (float)$s : 0.0;
    }

    protected function toInt($v)
    {
        if ($v === null || $v === '') return null;
        return (int) $v;
    }
}
