<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\AllocationsImport;
use App\Models\Allocation;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Morilog\Jalali\Jalalian;
use Carbon\Carbon;
use App\Exports\AllocationsExport;

class AllocationController extends Controller
{
    public function allocations(){
        return view('admin.allocations.allocations');
    }
    public function import(Request $request)
{
    $request->validate([
        'file' => 'required|mimes:xlsx,xls,csv'
    ]);

    Excel::import(new AllocationsImport, $request->file('file'));

    return back()->with('success', 'اطلاعات با موفقیت وارد شد.');
}

public function index(Request $request)
    {
        $query = Allocation::query();

        // فیلتر متناظر با فیلدهای فرم
        if ($request->filled('Shahrestan')) {
            $query->where('Shahrestan', $request->get('Shahrestan'));
        }

        if ($request->filled('masraf')) {
            $query->where('masraf', $request->get('masraf'));
        }

        // بازه تاریخ برای ستون erja (فرمت ورودی باید YYYY-MM-DD از فرم date باشد)
        // دریافت ورودی خام از درخواست (ممکن است شمسی یا میلادی باشد)
        $rawFrom = $request->get('from');
        $rawTo   = $request->get('to');

        $from = $this->parseToGregorianDate($rawFrom);
        $to   = $this->parseToGregorianDate($rawTo);

        // اگر هر دو تاریخ معتبر باشند از whereBetween استفاده کن (توجه: ترتیب از -> تا)
        if ($from && $to) {
            // اطمینان از ترتیب درست (اگر کاربر اشتباها معکوس زده باشد)
            if ($from <= $to) {
                $query->whereBetween('erja', [$from, $to]);
            } else {
                $query->whereBetween('erja', [$to, $from]);
            }
        } elseif ($from) {
            $query->where('erja', '>=', $from);
        } elseif ($to) {
            $query->where('erja', '<=', $to);
        }


        // جستجوی عمومی (ردیف، کلاسه، متقاضی و... )
        if ($request->filled('q')) {
            $q = $request->get('q');
            $query->where(function ($sub) use ($q) {
                $sub->where('row', 'like', "%{$q}%")
                    ->orWhere('kelace', 'like', "%{$q}%")
                    ->orWhere('motaghasi', 'like', "%{$q}%")
                    ->orWhere('Shahrestan', 'like', "%{$q}%");
            });
        }

        // مرتب‌سازی دلخواه (مثال: ?sort=sal&direction=asc)
        $allowedSorts = ['id','row','Shahrestan','sal','erja','kelace','q_m','V_m','sum','baghi'];
        $sort = $request->get('sort', 'id');
        $direction = strtolower($request->get('direction', 'desc')) === 'asc' ? 'asc' : 'desc';
        if (! in_array($sort, $allowedSorts)) {
            $sort = 'id';
        }
        $query->orderBy($sort, $direction);

        // صفحه‌بندی: پارامتر per_page قابل تنظیم است
        $perPage = (int) $request->get('per_page', 10);
        if ($perPage <= 0 || $perPage > 500) $perPage = 10;

        $allocations = $query->paginate($perPage)->appends($request->query());


        // داده‌های کمکی برای فیلترها (مثلا dropdown)
        $shahrestans = Allocation::select('Shahrestan')
            ->whereNotNull('Shahrestan')
            ->distinct()
            ->orderBy('Shahrestan')
            ->pluck('Shahrestan');

        $masrafs = Allocation::select('masraf')
            ->whereNotNull('masraf')
            ->distinct()
            ->orderBy('masraf')
            ->pluck('masraf');

        return view('admin.allocations.index', compact('allocations', 'shahrestans', 'masrafs'));
    }

    public function create()
    {
    // گرفتن بیشترین مقدار عددی ستون row (در صورتی که row به صورت string ذخیره شده)
    $maxRow = DB::table('allocations')
        ->select(DB::raw('MAX(CAST(`row` AS UNSIGNED)) as max_row'))
        ->value('max_row');

    $nextRow = $maxRow ? ((int)$maxRow + 1) : 1;

    // گزینه‌های شهرستان موجود در دیتابیس
    $shahrOptions = Allocation::query()
        ->select('Shahrestan')
        ->distinct()
        ->whereNotNull('Shahrestan')
        ->pluck('Shahrestan');

    // گزینه‌های نوع درخواست موجود در دیتابیس
    $darkhastOptions = Allocation::query()
        ->select('darkhast')
        ->distinct()
        ->whereNotNull('darkhast')
        ->pluck('darkhast');

    // گزینه‌های تخصیص موجود در دیتابیس
    $takhsisOptions = Allocation::query()
        ->select('Takhsis_group')
        ->distinct()
        ->whereNotNull('Takhsis_group')
        ->pluck('Takhsis_group');

    // گزینه‌های منطقه موجود در دیتابیس
    $mantagheOptions = Allocation::query()
        ->select('mantaghe')
        ->distinct()
        ->whereNotNull('mantaghe')
        ->pluck('mantaghe');

    // گزینه‌های واحد دبی موجود در دیتابیس
    $vahedOptions = Allocation::query()
        ->select('vahed')
        ->distinct()
        ->whereNotNull('vahed')
        ->pluck('vahed');

    return view('admin.allocations.create', compact('nextRow','darkhastOptions', 'takhsisOptions', 'shahrOptions','mantagheOptions','vahedOptions'));
}

public function computeSum(Request $request)
{
    $data = $request->all();

    // normalize inputs
    $code = array_key_exists('code', $data) && $data['code'] !== '' ? $data['code'] : null;
    $takhsis = array_key_exists('Takhsis_group', $data) && $data['Takhsis_group'] !== '' ? $data['Takhsis_group'] : null;

    // try to coerce V_m to float robustly
    $rawVm = (float)$data['V_m'] ?? null;
    // remove comma, persian separators, non-numeric (allow dot and minus)
    if (is_string($rawVm)) {
        // replace Persian digits with latin
        $pers = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
        foreach ($pers as $i => $p) $rawVm = str_replace($p, (string)$i, $rawVm);
        $rawVm = str_replace([',','٬',' '], ['', '', ''], $rawVm);
    }
    $currentVm = is_null($rawVm) || $rawVm === '' ? 0.0 : (float) $rawVm;

    $query = Allocation::query();

    if ($code !== null) {
        $query->where('code', $code);
    } else {
        $query->whereNull('code');
    }

    if ($takhsis !== null) {
        $query->where('Takhsis_group', $takhsis);
    } else {
        $query->whereNull('Takhsis_group');
    }

    // if id provided (edit), exclude that id
    if (!empty($data['id'])) {
        $query->where('id', '!=', (int)$data['id']);
    }

    // sum of V_m of other records
    $otherSum = (float) $query->sum('V_m');

    $final = $otherSum + $currentVm;

// خروجی با دو رقم اعشار بدون رند کردن
$finalFormatted = number_format($final, 2, '.', '');

return response()->json(['sum' => $finalFormatted]);
}


public function store(Request $request)
{
    // اعتبارسنجی
    $validated = $request->validate([
        'row'           => 'required|unique:allocations,row',
        'Shahrestan'    => 'nullable|string|max:255',
        'sal'           => 'nullable|integer',
        'erja'          => 'nullable|date',
        'code'          => 'nullable|integer',
        'mantaghe'      => 'nullable|string|max:255',
        'Abadi'         => 'nullable|string|max:255',
        'kelace'        => 'required|unique:allocations,kelace|max:255',
        'motaghasi'     => 'nullable|string|max:255',
        'darkhast'      => 'nullable|string|max:255',
        'Takhsis_group' => 'nullable|string|max:255',
        'masraf'        => 'nullable|string|max:255',
        'comete'        => 'nullable|date',
        'shomare'       => 'nullable|string|max:255',
        'date_shimare'  => 'nullable|date',
        'vahed'         => 'nullable|string|max:255',
        'q_m'           => 'nullable|integer',
        'V_m'           => 'nullable|numeric',
        't_mosavvab'    => 'nullable|numeric',
        //'sum'           => 'nullable|numeric',
        //'baghi'         => 'nullable|numeric',
        'mosavabat'     => 'nullable|string|max:255',
    ]);

    // تبدیل تاریخ شمسی به میلادی اگر لازم است
    $dateFields = ['erja','comete','date_shimare'];
    foreach($dateFields as $field) {
        if(!empty($validated[$field])) {
            // اگر تاریخ شمسی است و اعداد فارسی دارد
            $val = $validated[$field];
            // تبدیل اعداد فارسی به انگلیسی
            $val = str_replace(
                ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],
                ['0','1','2','3','4','5','6','7','8','9'],
                $val
            );
            try {
                $validated[$field] = Jalalian::fromFormat('Y/m/d', $val)->toCarbon()->format('Y-m-d');
            } catch (\Throwable $e) {
                // اگر تاریخ میلادی است، مستقیم قبول می‌کنیم
                $validated[$field] = Carbon::parse($val)->format('Y-m-d');
            }
        }
    }
    // محاسبه baghi در سرور (اختیاری)
    //$validated['baghi'] = (float)($validated['t_mosavvab'] ?? 0) - (float)($validated['sum'] ?? 0);

    $currentVm = isset($validated['V_m']) ? (float)$validated['V_m'] : 0.0;

    $query = Allocation::query();
    if (!empty($validated['code'])) $query->where('code', $validated['code']); else $query->whereNull('code');
    if (!empty($validated['Takhsis_group'])) $query->where('Takhsis_group', $validated['Takhsis_group']); else $query->whereNull('Takhsis_group');

    $otherSum = (float)$query->sum('V_m');
    $validated['sum'] = round($otherSum + $currentVm, 3);

    // محاسبه baghi اگر لازم است
    $t = isset($validated['t_mosavvab']) ? (float)$validated['t_mosavvab'] : 0.0;
    $validated['baghi'] = round($t - $validated['sum'], 3);

    Allocation::create($validated);
    // $allocation = Allocation::create($validated);
    // $allocation->update(['baghi' => $allocation->t_mosavvab - $allocation->sum]);
    
    return redirect()->route('allocations.index')->with('success', 'رکورد با موفقیت ایجاد شد.');
}

public function edit(Allocation $allocation){ return view('admin.allocations.edit', compact('allocation')); }



public function show(Request $request, $id)
{
    $allocation = Allocation::findOrFail($id);

    if ($request->wantsJson() || $request->ajax()) {
        return response()->json($allocation);
    }

    // fallback: اگر کسی مستقیم صفحه را خواست، می‌توانیم به صفحهٔ edit ریدایرکت کنیم
    return view('admin.allocations.edit', compact('allocation'));
}

public function update(Request $request, $id)
{
    $allocation = Allocation::findOrFail($id);

    $validated = $request->validate([
        'row'           => ['required', Rule::unique('allocations','row')->ignore($allocation->id)],
        'Shahrestan'    => 'nullable|string|max:255',
        'sal'           => 'nullable|integer',
        'erja'          => 'nullable|string', // ممکن است میلادی یا شمسی؛ تبدیل پایین انجام می‌شود
        'code'          => 'nullable|integer',
        'mantaghe'      => 'nullable|string|max:255',
        'Abadi'         => 'nullable|string|max:255',
        'kelace'        => ['required', Rule::unique('allocations','kelace')->ignore($allocation->id)],
        'motaghasi'     => 'nullable|string|max:255',
        'darkhast'      => 'nullable|string|max:255',
        'Takhsis_group' => 'nullable|string|max:255',
        'masraf'        => 'nullable|string|max:255',
        'comete'        => 'nullable|string',
        'shomare'       => 'nullable|string|max:255',
        'date_shimare'  => 'nullable|string',
        'vahed'         => 'nullable|string|max:255',
        'q_m'           => 'nullable|integer',
        'V_m'           => 'numeric|nullable',
        'sum'           => 'numeric|nullable',
        't_mosavvab'    => 'numeric|nullable',
        //'baghi'         => 'numeric|nullable',
        'mosavabat'     => 'nullable|string|max:255',
    ]);

    // helper: تبدیل اعداد فارسی به انگلیسی
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $english = ['0','1','2','3','4','5','6','7','8','9'];

    $dateFields = ['erja', 'comete', 'date_shimare'];
    foreach ($dateFields as $f) {
        if (!empty($validated[$f])) {
            $val = str_replace($persian, $english, $validated[$f]);

            // اگر ورودی فرمت YYYY/MM/DD شمسی باشد، سعی کن به میلادی تبدیل کنی
            try {
                // اگر سال >= 1300 -> شمسی
                if (preg_match('/^\d{4}\/\d{1,2}\/\d{1,2}$/', $val) && (int)explode('/',$val)[0] >= 1300) {
                    $validated[$f] = Jalalian::fromFormat('Y/m/d', $val)->toCarbon()->format('Y-m-d');
                } else {
                    // تلاش با Carbon
                    $validated[$f] = Carbon::parse($val)->format('Y-m-d');
                }
            } catch (\Throwable $e) {
                // اگر تبدیل نشد، پاکش کن
                $validated[$f] = null;
            }
        }
    }

    $t = isset($validated['t_mosavvab']) ? (float)$validated['t_mosavvab'] : (float)$allocation->t_mosavvab;
    $s = isset($validated['sum']) ? (float)$validated['sum'] : (float)$allocation->sum;
    $validated['baghi'] = round($t - $s, 3);

    $allocation->update($validated);

    // پاسخ JSON برای AJAX
    if ($request->wantsJson() || $request->ajax()) {
        return response()->json([
            'success' => true,
            'message' => 'تغییرات با موفقیت ذخیره شد',
            'data' => $allocation->fresh()
        ], 200);
    }

    return redirect()->route('admin.allocations.index')->with('success', 'تغییرات ذخیره شد');
}


public function destroy(Request $request, $id)
{
    $allocation = Allocation::findOrFail($id);
    $allocation->delete();

    // اگر درخواست AJAX یا خواستنده JSON است، پاسخ JSON بده
    if ($request->wantsJson() || $request->ajax()) {
        return response()->json([
            'success' => true,
            'message' => 'رکورد با موفقیت حذف شد'
        ], 200);
    }

    return back()->with('success', 'رکورد با موفقیت حذف شد.');
}


// validation helper
protected function validateData(Request $request, $id = null){
    return $request->validate([
      'row' => ['required','string', Rule::unique('allocations','row')->ignore($id)],
      'Shahrestan' => 'nullable|string',
      'sal' => 'nullable|integer',
      'erja' => 'nullable|date',
      'kelace' => ['nullable','string', Rule::unique('allocations','kelace')->ignore($id)],
      // ... بقیه فیلدها
    ]);
}

// تبدیل تاریخ اگر ورودی جلالی است (نمونه)
protected function convertDatesIfJalali(array $data){
    if(!empty($data['erja']) && preg_match('/^\d{4}\/\d{1,2}\/\d{1,2}$/',$data['erja'])){
        // مثال: 1402/01/12 -> به میلادی تبدیل کن (نیاز به بسته Morilog\Jalali)
        try{
            $data['erja'] = \Morilog\Jalali\Jalalian::fromFormat('Y/m/d', $data['erja'])->toCarbon()->format('Y-m-d');
        }catch(\Throwable $e){}
    }
    // تکرار برای comete و date_shimare
    return $data;
}



/**
 * تبدیل یک رشته تاریخ (شمسی یا میلادی) به تاریخ میلادی فرمت Y-m-d
 * - اگر ورودی شبیه 1403/10/22 یا 1403-10-22 باشه -> فرض می‌کنیم شمسی و تبدیل می‌کنیم.
 * - اگر سال <= 1400 (مثلاً 2025-01-12) باشه -> فرض می‌کنیم میلادی و به Carbon تبدیل می‌کنیم.
 * - در صورت نامعتبر بودن => بازگشت null
 */
private function parseToGregorianDate(?string $value): ?string
{
    if (empty($value)) return null;

    // نرمال‌سازی: تبدیل '-' به '/' و ترمیم فاصله‌ها
    $v = trim(str_replace('-', '/', $value));

    // اگر فرمت عددی با 3 بخش باشد (YYYY/MM/DD)
    if (preg_match('/^\d{2,4}\/\d{1,2}\/\d{1,2}$/', $v)) {
        $parts = explode('/', $v);
        $year = (int) $parts[0];

        // اگر سال بزرگتر یا مساوی 1300 فرض شمسی (سال‌های شمسی معمولاً 13xx یا 14xx)
        if ($year >= 1300) {
            try {
                // Jalalian::fromFormat نیاز به فرمت یکنواخت دارد
                $jalali = str_pad($parts[0], 4, '0', STR_PAD_LEFT) . '/'
                        . str_pad($parts[1], 2, '0', STR_PAD_LEFT) . '/'
                        . str_pad($parts[2], 2, '0', STR_PAD_LEFT);

                return Jalalian::fromFormat('Y/m/d', $jalali)->toCarbon()->format('Y-m-d');
            } catch (\Throwable $e) {
                return null;
            }
        } else {
            // فرض میلادی (مثلاً 2025/01/12)
            try {
                return Carbon::createFromFormat('Y/m/d', $v)->format('Y-m-d');
            } catch (\Throwable $e) {
                // سعی کن با پارس معمولی هم تبدیل کنی
                try {
                    return Carbon::parse($v)->format('Y-m-d');
                } catch (\Throwable $e2) {
                    return null;
                }
            }
        }
    }

    // اگر رشته‌ای است که Carbon می‌تواند parse کند (مثلاً 2025-01-12)
    try {
        return Carbon::parse($value)->format('Y-m-d');
    } catch (\Throwable $e) {
        return null;
    }
}

public function export()
{
    return Excel::download(new AllocationsExport , 'allocations.xlsx');
}




}
