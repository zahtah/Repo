<?php

namespace App\Http\Controllers;

use App\Models\Allocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function index(Request $request)
    {
        // فچ گزینه‌ها برای فیلترها
        $takhsisOptions = Allocation::query()
            ->select('Takhsis_group')
            ->distinct()
            ->whereNotNull('Takhsis_group')
            ->pluck('Takhsis_group')
            ->toArray();

        // initial codes list (برای زمانی که Takhsis_group مشخص باشد، در غیر اینصورت همه کدها)
        $codesAll = Allocation::query()
            ->select('code')
            ->distinct()
            ->whereNotNull('code')
            ->pluck('code')
            ->toArray();

        // فیلترها از request
        $takhsis = $request->get('Takhsis_group'); // or null or 'all'
        $code = $request->get('code'); // or null or 'all'

        // Build base query: اگر Takhsis_group انتخاب شده و != 'all' فیلتر بزن
        $base = Allocation::query();

        if ($takhsis && $takhsis !== 'all') {
            $base->where('Takhsis_group', $takhsis);
        }

        if ($code && $code !== 'all') {
            $base->where('code', $code);
        }

        // گروه‌بندی بر اساس code و محاسبات: حجم کل از t_mosavvab (MAX) و هزینه = SUM(sum)
        // فرض: برای هر code در یک Takhsis_group مقدار t_mosavvab یکیه، پس MAX یا MIN فرقی ندارند
        $reportQuery = (clone $base)
            ->select(
                'code',
                DB::raw('MAX(t_mosavvab) as total_volume'),
                DB::raw('ROUND(MAX(`sum`), 2) as cost'),
                DB::raw('ROUND(MAX(t_mosavvab) - MAX(`sum`), 2) as remaining')
            )
            ->whereNotNull('code') // نمایش تنها کدهای قابل معنی
            ->groupBy('code')
            ->orderBy('code');

        // pagination (اختیاری)
        $perPage = 25;
        $rows = $reportQuery->paginate($perPage)->withQueryString();

        return view('admin.reports.allocations', compact('rows', 'takhsisOptions', 'codesAll', 'takhsis', 'code'));
    }

    /**
     * Ajax endpoint -> returns codes available for a given Takhsis_group (or all)
     */
    public function codesForGroup(Request $request)
    {
        $takhsis = $request->get('Takhsis_group');

        $q = Allocation::query();

        if ($takhsis && $takhsis !== 'all') {
            $q->where('Takhsis_group', $takhsis);
        }

        $codes = $q->select('code')
            ->distinct()
            ->whereNotNull('code')
            ->orderBy('code')
            ->pluck('code');

        return response()->json(['codes' => $codes]);
    }
}
