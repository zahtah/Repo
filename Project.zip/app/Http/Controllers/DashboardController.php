<?php
namespace App\Http\Controllers;

use App\Models\Allocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        // 1) بار قبلی: درصد تحقق بر حسب Shahrestan (مثل قبل)
        $stats = Allocation::select(
                'Shahrestan',
                DB::raw('SUM(`sum`) as total_sum'),
                DB::raw('SUM(`t_mosavvab`) as total_mosavvab')
            )
            ->groupBy('Shahrestan')
            ->get()
            ->map(function ($item) {
                $item->percent = $item->total_mosavvab > 0
                    ? round(($item->total_sum / $item->total_mosavvab) * 100, 2)
                    : 0;
                return $item;
            });

        // 2) داده برای pie اول: تخصیص بر حسب Takhsis_group (مجموع t_mosavvab هر گروه)
        $groupData = Allocation::select('Takhsis_group', DB::raw('SUM(t_mosavvab) as total_mos'))
            ->whereNotNull('Takhsis_group')
            ->groupBy('Takhsis_group')
            ->orderByDesc('total_mos')
            ->get();

        // optionally limit to top N and aggregate others
        $topN = 8;
        $topGroups = $groupData->take($topN);
        $others = $groupData->slice($topN);
        $othersTotal = $others->sum('total_mos');
        $groupLabels = $topGroups->pluck('Takhsis_group')->map(fn($v)=> (string)$v)->toArray();
        $groupValues = $topGroups->pluck('total_mos')->map(fn($v)=> (float)$v)->toArray();
        if ($othersTotal > 0) {
            $groupLabels[] = 'سایر';
            $groupValues[] = (float)$othersTotal;
        }

        // 3) داده برای pie دوم: شمارش رکوردها بر حسب darkhast
        $darkhastData = Allocation::select('darkhast', DB::raw('COUNT(*) as cnt'))
            ->groupBy('darkhast')
            ->orderByDesc('cnt')
            ->get();

        $topM = 8;
        $topDark = $darkhastData->take($topM);
        $othersD = $darkhastData->slice($topM);
        $othersDCnt = $othersD->sum('cnt');
        $darkLabels = $topDark->pluck('darkhast')->map(fn($v)=> $v ? (string)$v : 'نامشخص')->toArray();
        $darkValues = $topDark->pluck('cnt')->map(fn($v)=> (int)$v)->toArray();
        if ($othersDCnt > 0) {
            $darkLabels[] = 'سایر';
            $darkValues[] = (int)$othersDCnt;
        }

        return view('admin.dashboard.index', compact('stats', 'groupLabels', 'groupValues', 'darkLabels', 'darkValues'));
    }
}
